package com.example.demo.Controller;


import com.example.demo.Modal.Manutencao;
import com.example.demo.Service.ManutencaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/manutencao")
public class ManutencaoController {

    @Autowired
    private ManutencaoService manutencaoService;

    @PostMapping
    public ResponseEntity<Manutencao> registrarManutencao(@RequestBody Manutencao manutencao) {
        Manutencao savedManutencao = manutencaoService.salvarManutencao(manutencao);
        return ResponseEntity.ok(savedManutencao);
    }

    @GetMapping("/porData")
    public List<Manutencao> obterManutencaoPorData(@RequestParam("data") LocalDate data) {
        return manutencaoService.getManutencaoPorData(data);
    }

    @GetMapping("/porEquipamento")
    public List<Manutencao> obterManutencaoPorEquipamento(@RequestParam("equipamentoId") Long equipamentoId) {
        return manutencaoService.getManutencaoPorEquipamento(equipamentoId);
    }

    @GetMapping("/porTipo")
    public List<Manutencao> obterManutencaoPorTipo(@RequestParam("tipoManutencao") String tipoManutencao) {
        return manutencaoService.getManutencaoPorTipo(tipoManutencao);
    }

    @PutMapping("/inativarEquipamento/{equipamentoId}")
    public ResponseEntity<String> inativarEquipamento(@PathVariable Long equipamentoId) {
        manutencaoService.inativarEquipamento(equipamentoId);
        return ResponseEntity.ok("Equipamento inativado com sucesso.");
    }
}
