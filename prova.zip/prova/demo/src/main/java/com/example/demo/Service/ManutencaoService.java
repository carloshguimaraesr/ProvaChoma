package com.example.demo.Service;


import com.example.demo.Modal.Equipamento;
import com.example.demo.Modal.Manutencao;
import com.example.demo.Repository.EquipamentoRepository;
import com.example.demo.Repository.ManutencaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ManutencaoService {

    @Autowired
    private ManutencaoRepository manutencaoRepository;

    @Autowired
    private EquipamentoRepository equipamentoRepository;

    public List<Manutencao> getManutencaoPorData(LocalDate data) {
        return manutencaoRepository.findByDataRealizacao(data);
    }

    public List<Manutencao> getManutencaoPorEquipamento(Long equipamentoId) {
        return manutencaoRepository.findByEquipamentoId(equipamentoId);
    }

    public List<Manutencao> getManutencaoPorTipo(String tipoManutencao) {
        return manutencaoRepository.findByTipoManutencao(tipoManutencao);
    }

    public Manutencao salvarManutencao(Manutencao manutencao) {
        Optional<Equipamento> equipamento = equipamentoRepository.findById(manutencao.getEquipamento().getId());
        if (equipamento.isPresent()) {
            manutencao.setEquipamento(equipamento.get());
            return manutencaoRepository.save(manutencao);
        }
        throw new IllegalArgumentException("Equipamento não encontrado!");
    }

    public void inativarEquipamento(Long equipamentoId) {
        Optional<Equipamento> equipamento = equipamentoRepository.findById(equipamentoId);
        if (equipamento.isPresent()) {
            Equipamento eq = equipamento.get();
            eq.setAtivo(false);
            equipamentoRepository.save(eq);
        } else {
            throw new IllegalArgumentException("Equipamento não encontrado!");
        }
    }
}
