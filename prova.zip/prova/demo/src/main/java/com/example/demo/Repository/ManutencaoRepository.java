package com.example.demo.Repository;



import com.example.demo.Modal.Manutencao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ManutencaoRepository extends JpaRepository<Manutencao, Long> {
    List<Manutencao> findByDataRealizacao(LocalDate dataRealizacao);
    List<Manutencao> findByEquipamentoId(Long equipamentoId);
    List<Manutencao> findByTipoManutencao(String tipoManutencao);
}
